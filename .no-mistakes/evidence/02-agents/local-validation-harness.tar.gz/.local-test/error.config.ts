import { defineConfig } from '@playwright/test';
import original from './playwright.config.ts';
export default defineConfig({...original, webServer: {...original.webServer, command:'npx vite dev --port 3107', cwd:'/Users/moeghashim/.no-mistakes/worktrees/7fcac8a8339b/01M6DZRHRBF3QX8AX1F7AWT2V1/apps/web'}});
