import {neonConfig} from '@neondatabase/serverless';
neonConfig.wsProxy='127.0.0.1:5548/v2';
neonConfig.useSecureWebSocket=false;
neonConfig.pipelineConnect=false;
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
Object.assign(require('@neondatabase/serverless').neonConfig,{wsProxy:'127.0.0.1:5548/v2',useSecureWebSocket:false,pipelineConnect:false});
