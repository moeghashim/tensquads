import { defineConfig } from '@playwright/test';
import original from '../playwright.config.ts';
export default defineConfig({ ...original, testDir: '../e2e', use: { ...original.use, baseURL: 'http://localhost:3107' }, webServer: { ...original.webServer, command: 'npm run dev -w @tensquads/web -- --port 3107', url: 'http://localhost:3107' } });
