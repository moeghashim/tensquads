import {tanstackStart} from '@tanstack/react-start/plugin/vite';
import viteReact from '@vitejs/plugin-react';
import {defineConfig} from 'vite';
export default defineConfig({ssr:{external:['@neondatabase/serverless'],optimizeDeps:{exclude:['@neondatabase/serverless']}},environments:{ssr:{optimizeDeps:{exclude:['@neondatabase/serverless']}}},resolve:{tsconfigPaths:true,alias:{'@neondatabase/serverless':'/Users/moeghashim/.no-mistakes/worktrees/7fcac8a8339b/01M6DZRHRBF3QX8AX1F7AWT2V1/.local-test/neon.ts'}},plugins:[tanstackStart(),viteReact()]});
