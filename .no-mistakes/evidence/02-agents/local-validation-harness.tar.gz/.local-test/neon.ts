import {neonConfig} from '/Users/moeghashim/.no-mistakes/worktrees/7fcac8a8339b/01M6DZRHRBF3QX8AX1F7AWT2V1/node_modules/@neondatabase/serverless/index.mjs';
neonConfig.wsProxy='127.0.0.1:5548/v2';
neonConfig.useSecureWebSocket=false;
neonConfig.pipelineConnect=false;
export * from '/Users/moeghashim/.no-mistakes/worktrees/7fcac8a8339b/01M6DZRHRBF3QX8AX1F7AWT2V1/node_modules/@neondatabase/serverless/index.mjs';
