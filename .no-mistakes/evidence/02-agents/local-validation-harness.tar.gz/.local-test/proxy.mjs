import {WebSocketServer} from 'ws';
import net from 'node:net';
const server=new WebSocketServer({host:'127.0.0.1',port:5548});
server.on('connection',ws=>{const tcp=net.connect(5547,'127.0.0.1'); ws.on('message',bytes=>tcp.write(bytes)); tcp.on('data',bytes=>{if(ws.readyState===1)ws.send(bytes)}); tcp.on('error',()=>ws.close()); tcp.on('close',()=>ws.close());ws.on('close',()=>tcp.destroy());});
