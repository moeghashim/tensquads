import { test, expect } from '@playwright/test';
import { installPinnedFonts } from './fonts.ts';

test('an unauthenticated visitor to agents is sent to sign in', async ({ page }) => {
  await installPinnedFonts(page);
  await page.goto('/agents');
  await expect(page).toHaveURL(/\/signin$/);
  await expect(page.getByRole('button', { name: 'Sign in', exact: true })).toBeVisible();
  await expect(page.locator("[data-handler='a.open']")).toHaveCount(0);
  await page.screenshot({path: '/Users/moeghashim/.no-mistakes/evidence/01M6DZRHRBF3QX8AX1F7AWT2V1/agents-unauthenticated.png', fullPage: true});
});
