import { openPostgres } from '@tensquads/adapters';
import { replaceDemoAccount } from '../packages/seed/src/demo-account.ts';
import { test as base, expect } from './support.ts';
import { deleteWorkspaceAccount, installLocalFonts } from './workspace.ts';
export { expect, installLocalFonts };
export const test = base.extend<{accountId:string},{workspaceUser:{accountId:string;userId:string;email:string;password:string}}>({
 workspaceUser: [async ({},use)=>{
  const accountId='disposable-agents-gate'; const userId='user_local_test';
  const db=openPostgres(process.env.TEST_DATABASE_URL!);
  try {await db.migrate(); await replaceDemoAccount(db.db,accountId,userId);} finally {await db.close();}
  try {await use({accountId,userId,email:'local@example.com',password:''});} finally {await deleteWorkspaceAccount(accountId);}
 },{scope:'worker'}],
 accountId: [async ({workspaceUser},use)=>{
  const db=openPostgres(process.env.TEST_DATABASE_URL!);
  try {await replaceDemoAccount(db.db,workspaceUser.accountId,workspaceUser.userId);} finally {await db.close();}
  await use(workspaceUser.accountId);
 },{auto:true}]
});
export async function openWorkspace(page:any,_user:any){
 await page.setExtraHTTPHeaders({Authorization:`Bearer ${process.env.LOCAL_AUTH_TOKEN}`});
 await page.route('https://offline.clerk.accounts.dev/**', (route:any)=>route.abort());
 await page.goto('/overview');
 await expect(page.getByRole('navigation',{name:'Workspace'})).toBeVisible();
}
