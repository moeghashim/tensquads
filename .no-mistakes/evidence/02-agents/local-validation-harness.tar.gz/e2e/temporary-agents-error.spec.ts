import { test, expect } from '@playwright/test';
import { installPinnedFonts } from './fonts.ts';
test('an authenticated failed database read shows the router error page', async ({page}) => {
  await installPinnedFonts(page);
  await page.setExtraHTTPHeaders({Authorization: `Bearer ${process.env.LOCAL_AUTH_TOKEN}`});
  await page.route('https://offline.clerk.accounts.dev/**', route => route.abort());
  const response = await page.goto('/agents');
  console.log('Observed route',new URL(page.url()).pathname,'HTTP',response?.status());
  await expect(page.getByText('Something went wrong!', {exact:true})).toBeVisible();
  await expect(page).toHaveURL(/\/agents$/);
  await expect(page.locator("[data-handler='a.open']")).toHaveCount(0);
  await page.screenshot({path:'/Users/moeghashim/.no-mistakes/evidence/01M6DZRHRBF3QX8AX1F7AWT2V1/agents-read-error.png',fullPage:true});
});
